"""
3_collect_data.py
═══════════════════════════════════════════════════════════════════════════════
Script Pengumpulan RAW DATA E-NOSE Kopi via Serial ke CSV (dengan Live Plot).

Metadata sample tersedia pada KNOWN_SAMPLES di script ini. Baseline akuisisi
aktif dimulai dari B32 dengan sensor MQ3 serta temperature/humidity.

PENTING:
  Script ini adalah collector MANUAL yang mengirim #start; dari laptop.
  Jika pengambilan data dimulai dari LCD Nextion, CSV ditulis oleh
  scripts/lcd_acquisition_service.py (passive listener), bukan file ini.

Flow Akuisisi Aktif (mulai baseline B32):
  Satu Run  : PURGING (25 s) ──► COLLECTING (5 s) ──► Simpan Raw Data
  Satu File : 5 Run per Sampel ──► Output CSV: <sample_id>_<batch_id>.csv

Metadata per Baris:
  timestamp, sample_id, roast_level, origin, batch_id, run_id, phase, sample_idx,
  10 Raw ADC Readings (adc_tgs822, adc_mq135, adc_mq3, adc_tgs2611, adc_tgs2620,
  adc_tgs2600, adc_tgs2602, adc_mq8, adc_tgs813, adc_tgs816), temperature, humidity

Cara Pakai:
  python 3_collect_data.py
  python 3_collect_data.py --port COM11 --sample M-TOR --batch B32 --arm-hardware
  python 3_collect_data.py --no-plot
═══════════════════════════════════════════════════════════════════════════════
"""

import argparse
import json
import os
import sys
import time
import threading
import uuid
from pathlib import Path
from collections import deque
from datetime import datetime

import pandas as pd
from serial import Serial

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.animation as animation

from acquisition_schema import (
    ADC_COLS,
    is_sensor_payload,
    sensor_payload_rejection_reason,
    sensor_row_from_payload,
)
from serial_wire import serial_json_frames
from validate_acquisition import validate_file

try:
    matplotlib.use('TkAgg')
except Exception:
    pass

# ─── Konfigurasi Akuisisi Default ──────────────────────────────────────────────
BAUD_RATE        = 115200
CURRENT_PCB_PORT = 'COM11'  # FT232RL onboard PCB kedua; override via --port untuk alat lain
OUTPUT_DIR       = os.path.normpath(os.path.join(os.path.dirname(__file__), '..', 'data', 'raw'))
ACQ_PURGE_S      = 25   # Durasi purging per run (detik)
ACQ_COLLECT_S    = 5   # Durasi collecting per run (detik)
ACQ_REPETITIONS  = 5   # Jumlah run per sampel kopi

# ─── Database Sampel Eksperimen (Predefined Metadata) ───────────────────────────
KNOWN_SAMPLES = {
    # LIGHT ROAST
    'L-MAN': {'roast_level': 'light',  'origin': 'Arabika Manglayang Jawa Barat'},
    'L-RAT': {'roast_level': 'light',  'origin': 'Arabika Ratawali Aceh'},
    'L-GAY': {'roast_level': 'light',  'origin': 'Arabika Gayo Aceh'},
    'L-MER': {'roast_level': 'light',  'origin': 'Arabika Merapi'},
    'L-TEM': {'roast_level': 'light',  'origin': 'Arabika Temanggung'},
    'L-CAT': {'roast_level': 'light',  'origin': 'Arabika Catuji Mekarwangi'},
    'L-GAW': {'roast_level': 'light',  'origin': 'Arabika Gayo Wine'},
    'L-MING': {'roast_level': 'light', 'origin': 'Arabika Sumatra Utara'},
    'L-TOR': {'roast_level': 'light', 'origin': 'Arabika Toraja Washed'},
    'L-GRB': {'roast_level': 'light', 'origin': 'Arabika Redbourbon Gayo Aceh Natural'},
    'L-CAW': {'roast_level': 'light', 'origin': 'CAW'},
    
    # MEDIUM ROAST
    'M-MAN': {'roast_level': 'medium', 'origin': 'Arabika Manglayang Jawa Barat'},
    'M-RAT': {'roast_level': 'medium', 'origin': 'Arabika Ratawali Aceh'},
    'M-TEM': {'roast_level': 'medium', 'origin': 'Arabika Temanggung'},
    'M-TIM': {'roast_level': 'medium', 'origin': 'Arabika Timor Leste'},
    # 'M-MUK': {'roast_level': 'medium', 'origin': 'Arabika Temanggung Mukidi'},
    'M-CAT': {'roast_level': 'medium', 'origin': 'Arabika Catuji Mekarwangi'},
    'M-GAW': {'roast_level': 'medium', 'origin': 'Arabika Gayo Wine'},
    'M-MING': {'roast_level': 'medium', 'origin': 'Arabika Sumatra Utara'},
    'M-TOR': {'roast_level': 'medium', 'origin': 'Arabika Toraja Washed'},
    'M-GRB': {'roast_level': 'medium', 'origin': 'Arabika Redbourbon Gayo Aceh Natural'},
    'M-MUK': {'roast_level': 'medium', 'origin': 'Arabika Temanggung Mukidi'},
    'M-CAW': {'roast_level': 'medium', 'origin': 'CAW'},

    # DARK ROAST
    'D-MAN': {'roast_level': 'dark',   'origin': 'Arabika Manglayang Jawa Barat'},
    'D-RAT': {'roast_level': 'dark',   'origin': 'Arabika Ratawali Aceh'},
    'D-GAY': {'roast_level': 'dark',   'origin': 'Arabika Gayo Aceh'},
    'D-BAR': {'roast_level': 'dark',   'origin': 'Arabika Jawa Barat'},
    'D-TEM': {'roast_level': 'dark',   'origin': 'Arabika Temanggung Mukidi'},
    'D-CAT': {'roast_level': 'dark',   'origin': 'Arabika Catuji Mekarwangi'},
    'D-GAW': {'roast_level': 'dark',   'origin': 'Arabika Gayo Wine'},
    'D-MUK': {'roast_level': 'dark',   'origin': 'Arabika Temanggung Mukidi Roasting Sendiri'},
    'D-MING': {'roast_level': 'dark', 'origin': 'Arabika Sumatra Utara'},
    'D-TOR': {'roast_level': 'dark',   'origin': 'Arabika Toraja Washed'},
    'D-GRB': {'roast_level': 'dark', 'origin': 'Arabika Redbourbon Gayo Aceh Natural'},
}

VALID_ROAST_LEVELS = ['light', 'medium', 'dark']

SENSOR_CONFIG = {
    'adc_tgs2600': {'label': 'TGS2600', 'color': "#FF7664", 'group': 'TGS'},
    'adc_tgs2602': {'label': 'TGS2602', 'color': "#FEFFA7", 'group': 'TGS'},
    'adc_tgs816':  {'label': 'TGS816',  'color': '#76FF03', 'group': 'TGS'},
    'adc_tgs813':  {'label': 'TGS813',  'color': "#59FFF1", 'group': 'TGS'},
    'adc_mq8':     {'label': 'MQ8',     'color': "#006EFF", 'group': 'MQ'},
    'adc_tgs2611': {'label': 'TGS2611', 'color': "#7300BF", 'group': 'TGS'},
    'adc_tgs2620': {'label': 'TGS2620', 'color': "#FF18BA", 'group': 'TGS'},
    'adc_tgs822':  {'label': 'TGS822',  'color': '#00E676', 'group': 'TGS'},
    'adc_mq135':   {'label': 'MQ135',   'color': '#FF6D00', 'group': 'MQ'},
    'adc_mq3':     {'label': 'MQ3',     'color': '#FF3D00', 'group': 'MQ'},
}

# ─── CLI Argument Parser ──────────────────────────────────────────────────────
def parse_args():
    p = argparse.ArgumentParser(description='E-NOSE Kopi — Pengumpulan Raw Data')
    p.add_argument('--port',        type=str, default=CURRENT_PCB_PORT,
                   help='Port Serial (default COM11; override untuk alat lain)')
    p.add_argument('--sample',      type=str, default=None, help='Sample ID (misal L-MAN, M-TEM, D-RAT)')
    p.add_argument('--roast-level', type=str, default=None, help='Roast Level (light, medium, dark)')
    p.add_argument('--origin',      type=str, default=None, help='Asal Kopi (Origin)')
    p.add_argument('--batch',       type=str, default=None, help='Batch ID (misal B01)')
    p.add_argument('--baud',        type=int, default=BAUD_RATE)
    p.add_argument(
        '--purge-s', type=int, default=ACQ_PURGE_S,
        help='Ekspektasi durasi purging firmware per run (default 25 s)'
    )
    p.add_argument(
        '--collect-s', type=int, default=ACQ_COLLECT_S,
        help='Ekspektasi durasi collecting firmware per run (default 5 s)'
    )
    p.add_argument(
        '--repetitions', type=int, default=ACQ_REPETITIONS,
        help='Ekspektasi jumlah run firmware (default 5)'
    )
    p.add_argument('--no-plot',     action='store_true', help='Matikan GUI grafik real-time')
    p.add_argument('--arm-hardware', action='store_true',
                   help='Izin eksplisit untuk membuka port dan mengirim #start;')
    return p.parse_args()


# ─── Interactive Prompt Helpers ───────────────────────────────────────────────
def prompt_port():
    try:
        import serial.tools.list_ports
        ports = list(serial.tools.list_ports.comports())
    except Exception:
        ports = []

    if ports:
        print("\n📡 Port Serial yang tersedia:")
        for i, p in enumerate(ports):
            print(f"  [{i}] {p.device}  – {p.description}")
        idx = input("Pilih nomor port (atau ketik nama port langsung): ").strip()
        try:
            num = int(idx)
            if 0 <= num < len(ports):
                return ports[num].device
            else:
                return f"COM{num}"
        except ValueError:
            return idx
    else:
        return input("Masukkan nama port Serial (misal COM11): ")

def prompt_metadata():
    """Meminta input Sample ID, Roast Level, Origin, dan Batch ID secara interaktif."""
    print("\n📋 SAMPLING METADATA ENTRY")
    print("Daftar Sample ID Terdaftar:")
    for sid, info in KNOWN_SAMPLES.items():
        print(f"  • {sid:<6} : {info['roast_level'].upper():<7} | {info['origin']}")

    # 1. Sample ID
    sid = input("\nMasukkan Sample ID (misal L-MAN): ").strip().upper()

    if sid in KNOWN_SAMPLES:
        default_roast = KNOWN_SAMPLES[sid]['roast_level']
        default_origin = KNOWN_SAMPLES[sid]['origin']
        print(f"  ✓ Terdeteksi preset: Roast={default_roast}, Origin={default_origin}")

        roast_level = KNOWN_SAMPLES[sid]['roast_level']

        origin_in = input(f"Masukkan Origin [{default_origin}]: ").strip()
        origin = origin_in if origin_in else default_origin
    else:
        roast_level = input("Masukkan Roast Level (light/medium/dark): ").strip().lower()
        origin = input("Masukkan Origin (asal kopi): ").strip()

    # Batch ID
    batch_in = input("Masukkan Batch ID [default: B01]: ").strip().upper()
    batch_id = batch_in if batch_in else "B01"

    return sid, roast_level, origin, batch_id


# ─── Data Collector & Store Thread ──────────────────────────────────────────
class RawDataCollector:
    def __init__(self, ser, sample_id, roast_level, origin, batch_id, out_csv):
        self.ser = ser
        self.sample_id = sample_id
        self.roast_level = roast_level
        self.origin = origin
        self.batch_id = batch_id
        self.out_csv = out_csv
        self.lock = threading.Lock()

        self.rows = []
        self.acquisition_done = False
        self.stop_requested = False
        self.complete_received = False
        self.failure_reason = 'acquisition_not_completed'
        self.start_seen = False
        self.start_command_sent = False

        # Data Deques untuk Live Plotting
        self.max_plot_pts = 600
        self.timestamps = deque(maxlen=self.max_plot_pts)
        self.sensor_data = {col: deque(maxlen=self.max_plot_pts) for col in ADC_COLS}

        # Status State
        self.phase = 'idle'
        self.cycle = 0          # run_id (1 s.d. cycles_total)
        self.cycles_total = ACQ_REPETITIONS
        self.collect_s = ACQ_COLLECT_S
        self.purge_s = ACQ_PURGE_S
        self.status_msg = 'Menunggu data serial...'

    def run(self):
        """Thread penerima data Serial dari ATmega 2560."""
        try:
            self.ser.write(b'#start;')
            self.start_command_sent = True
            print("📤 Mengirim perintah #start; ke ATmega 2560...\n")
            time.sleep(0.5)

            last_valid = time.monotonic()
            for data in serial_json_frames(self.ser):
                if self.acquisition_done or self.stop_requested:
                    break
                if data is None:
                    if self.start_seen and time.monotonic() - last_valid > 12:
                        self.failure_reason = 'host_receive_timeout'
                        break
                    continue
                if data.get('event') == 'TRANSPORT_ERROR':
                    self.failure_reason = 'serial_frame_invalid'
                    break
                if data.get('event') == 'ACQ_START' and self.start_seen:
                    self.failure_reason = 'duplicate_acq_start'
                    break
                last_valid = time.monotonic()
                if data.get('event') == 'ACQ_START' and data.get('mode') != 'labeled_data':
                    self.failure_reason = 'unexpected_ai_test_session'
                    break
                if data.get('event') == 'ACQ_START':
                    self.start_seen = True
                if not self.start_seen:
                    continue

                event = data.get('event', '')

                if event == 'ACQ_START':
                    actual_collect_s = data.get('collect_s', self.collect_s)
                    actual_purge_s = data.get('purge_s', self.purge_s)
                    actual_cycles = data.get('cycles_total', self.cycles_total)

                    expected_contract = (
                        self.cycles_total,
                        self.purge_s,
                        self.collect_s,
                    )
                    actual_contract = (
                        actual_cycles,
                        actual_purge_s,
                        actual_collect_s,
                    )
                    if actual_contract != expected_contract:
                        self.failure_reason = 'firmware_timing_contract_mismatch'
                        break

                    self.collect_s = actual_collect_s
                    self.purge_s = actual_purge_s
                    self.cycles_total = actual_cycles
                    self.cycle = data.get('cycle', 1)
                    self.phase = data.get('phase', 'purging')
                    self.status_msg = f"🚀 Start: Run 01/{self.cycles_total:02d} ({self.phase.upper()})"
                    print(f"🚀 Akuisisi Dimulai — {self.cycles_total} Run × ({self.purge_s}s purging + {self.collect_s}s collecting)")
                    continue

                if event == 'PHASE_CHANGE':
                    self.cycle = data.get('cycle', self.cycle)
                    self.phase = data.get('phase', self.phase)
                    self.status_msg = f"Phase -> {self.phase.upper()} (Run {self.cycle:02d}/{self.cycles_total:02d})"
                    print(f"  🔄 Phase: {self.phase.upper()} | Run {self.cycle:02d}/{self.cycles_total:02d}")
                    continue

                if event == 'ACQ_COMPLETE':
                    total = data.get('total_samples', len(self.rows))
                    if (data.get('cycles') != 5 or type(total) is not int or
                            total != len(self.rows)):
                        self.failure_reason = 'completion_count_mismatch'
                        break
                    self.status_msg = f"✅ Akuisisi Selesai ({total} Sampel Raw Data)"
                    print(
                        f"\n✅ {self.cycles_total} Run selesai! "
                        f"Total sampel raw data: {total}"
                    )
                    self.acquisition_done = True
                    self.complete_received = True
                    self.failure_reason = ''
                    continue

                if event == 'ACQ_STOP':
                    self.failure_reason = 'acquisition_stopped'
                    self.status_msg = "⏹️ Akuisisi Dihentikan Manual"
                    print("\n⏹️ Akuisisi dihentikan oleh user.")
                    self.acquisition_done = True
                    continue

                # Fail-closed: event/control frame yang tidak dikenali tidak
                # pernah dianggap sensor sample.
                if event:
                    print(f"  [event diabaikan] {event}")
                    continue

                if not is_sensor_payload(data):
                    print(
                        "  [payload sensor ditolak] "
                        f"{sensor_payload_rejection_reason(data)}"
                    )
                    self.failure_reason = 'invalid_sensor_frame'
                    break

                row = sensor_row_from_payload(
                    data,
                    sample_id=self.sample_id,
                    roast_level=self.roast_level,
                    origin=self.origin,
                    batch_id=self.batch_id,
                )
                phase = row['phase']
                cycle = int(row['run_id'])
                sample_idx = int(row['sample_idx'])

                with self.lock:
                    self.rows.append(row)
                    self.phase = phase
                    self.cycle = cycle

                    # Push ke plot deques
                    t_sec = len(self.rows)
                    self.timestamps.append(t_sec)
                    for col in ADC_COLS:
                        self.sensor_data[col].append(row[col])

                    self.status_msg = f"Run {cycle:02d}/{self.cycles_total:02d} | {phase.upper()} #{sample_idx}"

        except Exception as e:
            self.failure_reason = 'serial_reader_error'
            print(f"\n❌ Error serial loop: {e}")
        finally:
            self.acquisition_done = True


# ─── Live Plot GUI Window ────────────────────────────────────────────────────
def run_live_gui(collector):
    plt.style.use('dark_background')
    fig = plt.figure(figsize=(14, 8), facecolor='#0D1117')
    fig.canvas.manager.set_window_title(
        f'E-NOSE Kopi — Real-Time Raw Data [{collector.sample_id} | {collector.batch_id}]')

    gs = fig.add_gridspec(2, 1, height_ratios=[1, 1], hspace=0.3, left=0.06, right=0.98, top=0.91, bottom=0.07)

    ax_tgs = fig.add_subplot(gs[0])
    ax_mq  = fig.add_subplot(gs[1])

    for ax in [ax_tgs, ax_mq]:
        ax.set_facecolor('#161B22')
        ax.grid(True, alpha=0.15, color='#30363D')
        ax.tick_params(colors='#8B949E', labelsize=8)
        for spine in ax.spines.values():
            spine.set_color('#30363D')

    ax_tgs.set_title('TGS Series Sensors (Raw ADC)', fontsize=10, color='#58A6FF', fontweight='bold', loc='left')
    ax_tgs.set_ylabel('ADC Value', fontsize=8, color='#8B949E')

    ax_mq.set_title('MQ Series Sensors (Raw ADC)', fontsize=10, color='#F0883E', fontweight='bold', loc='left')
    ax_mq.set_ylabel('ADC Value', fontsize=8, color='#8B949E')
    ax_mq.set_xlabel('Sampel Total (detik)', fontsize=8, color='#8B949E')

    fig.suptitle(f'E-NOSE Raw Data — Sample: {collector.sample_id} ({collector.roast_level.upper()}) | Batch: {collector.batch_id}',
                 fontsize=12, color='#E6EDF3', fontweight='bold', y=0.97)

    lines = {}
    for col in ADC_COLS:
        cfg = SENSOR_CONFIG[col]
        ax = ax_tgs if cfg['group'] == 'TGS' else ax_mq
        line, = ax.plot([], [], color=cfg['color'], linewidth=1.3, alpha=0.9, label=cfg['label'])
        lines[col] = line

    ax_tgs.legend(loc='upper right', fontsize=7, ncol=4, framealpha=0.3, facecolor='#161B22', edgecolor='#30363D', labelcolor='#C9D1D9')
    ax_mq.legend(loc='upper right', fontsize=7, ncol=3, framealpha=0.3, facecolor='#161B22', edgecolor='#30363D', labelcolor='#C9D1D9')

    status_text = fig.text(0.06, 0.94, 'Status: Menyiapkan...', fontsize=9, color='#3FB950', fontweight='bold')

    def update(frame):
        with collector.lock:
            if not collector.timestamps:
                return list(lines.values())

            ts = list(collector.timestamps)
            for col in ADC_COLS:
                vals = list(collector.sensor_data[col])
                lines[col].set_data(ts[:len(vals)], vals)

            msg = collector.status_msg
            status_text.set_text(f"Status: {msg} | Total Data: {len(collector.rows)} sampel")

            if collector.phase == 'collecting':
                status_text.set_color('#3FB950')
            elif collector.phase == 'purging':
                status_text.set_color('#58A6FF')

        for ax in [ax_tgs, ax_mq]:
            ax.relim()
            ax.autoscale_view()
            if len(ts) > 1:
                ax.set_xlim(max(0, ts[0]), ts[-1] + 2)

        if collector.acquisition_done:
            status_text.set_text(
                f"[OK] {collector.cycles_total} Run Selesai! "
                f"CSV: {os.path.basename(collector.out_csv)}"
            )
            status_text.set_color('#A371F7')

        return list(lines.values())

    ani = animation.FuncAnimation(fig, update, interval=250, blit=False, cache_frame_data=False)

    def on_close(event):
        collector.stop_requested = True

    fig.canvas.mpl_connect('close_event', on_close)
    plt.show(block=True)


# ─── Main Execution ───────────────────────────────────────────────────────────
def main():
    if hasattr(sys.stdout, 'reconfigure'):
        try:
            sys.stdout.reconfigure(encoding='utf-8')
        except Exception:
            pass

    args = parse_args()

    # Guard before touching COM/USB: no unattended or accidental start.
    if not args.arm_hardware:
        print("Hardware DISARMED: perlu --arm-hardware dan pengawasan onsite.")
        return 2

    port = args.port or prompt_port()

    # Dapatkan metadata sampel
    if args.sample:
        sample_id = args.sample.upper()
        if sample_id in KNOWN_SAMPLES:
            roast_level = KNOWN_SAMPLES[sample_id]['roast_level']
            origin      = args.origin      or KNOWN_SAMPLES[sample_id]['origin']
        else:
            roast_level = args.roast_level or 'custom'
            origin      = args.origin      or 'custom'
        batch_id = (args.batch or 'B01').upper()
    else:
        sample_id, roast_level, origin, batch_id = prompt_metadata()

    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Format Nama File: <sample_id>_<batch_id>.csv (contoh: L-MAN_B01.csv)
    base_filename = f"{sample_id}_{batch_id}.csv"
    out_csv = os.path.join(OUTPUT_DIR, base_filename)

    # Perlindungan File Tertimpa (Accidental Overwrite Protection)
    if os.path.exists(out_csv):
        timestamp_suffix = datetime.now().strftime('%Y%m%d_%H%M%S')
        out_csv = os.path.join(OUTPUT_DIR, f"{sample_id}_{batch_id}_{timestamp_suffix}.csv")
        print(f"⚠️  File {base_filename} sudah ada. Nama file disesuaikan menjadi: {os.path.basename(out_csv)}")

    print(f"""
╔══════════════════════════════════════════════════════════════════════╗
║           E-NOSE Kopi — Pengumpulan Raw Data                         ║
╠══════════════════════════════════════════════════════════════════════╣
║  Sample ID    : {sample_id:<52} ║
║  Roast Level  : {roast_level.upper():<52} ║
║  Origin       : {origin:<52} ║
║  Batch ID     : {batch_id:<52} ║
║  Port Serial  : {port:<52} ║
║  Skema Run    : {ACQ_REPETITIONS} Run × ({ACQ_PURGE_S}s Purging + {ACQ_COLLECT_S}s Collecting){'':<14} ║
║  Output File  : {os.path.basename(out_csv):<52} ║
╚══════════════════════════════════════════════════════════════════════╝
""")

    # ── Buka Serial ──────────────────────────────────────────────────────────
    try:
        ser = Serial(port=port, baudrate=args.baud, timeout=2)
        print(f"✅ Serial terbuka: {port} @ {args.baud} baud")
    except Exception as e:
        print(f"❌ Gagal membuka Serial: {e}")
        sys.exit(1)

    time.sleep(2)  # Wait for ATmega boot

    collector = RawDataCollector(ser, sample_id, roast_level, origin, batch_id, out_csv)
    # Nilai CLI adalah ekspektasi kontrak host. Firmware tetap menjadi sumber
    # kebenaran durasi/jumlah siklus dan mengirim nilai aktual lewat ACQ_START.
    collector.purge_s = args.purge_s
    collector.collect_s = args.collect_s
    collector.cycles_total = args.repetitions
    t_thread = threading.Thread(target=collector.run, daemon=True)
    t_thread.start()

    try:
        if not args.no_plot:
            print("📊 Membuka window grafik real-time...")
            run_live_gui(collector)
        else:
            print("⏳ Memproses data (mode tanpa GUI)...")
            while not collector.acquisition_done:
                time.sleep(0.5)

    except KeyboardInterrupt:
        print("\n⚠️ Dihentikan oleh user (Ctrl+C)")
        collector.stop_requested = True
    finally:
        collector.acquisition_done = True
        try:
            # If MCU ACK was lost after #start, the MCU may still be driving
            # a valve. Attempt #stop whenever start was transmitted.
            if collector.start_command_sent and not collector.complete_received:
                ser.write(b'#stop;')
                print("📤 Mengirim #stop; karena sesi belum complete...")
        except Exception:
            pass
        time.sleep(0.5)
        ser.close()

    # ── Simpan RAW DATA ke CSV ─────────────────────────────────────────────────
    rows = collector.rows
    if rows:
        df = pd.DataFrame(rows)

        # Urutan Kolom Standard Metadata & Raw ADC
        ordered_cols = [
            'timestamp', 'sample_id', 'roast_level', 'origin', 'batch_id',
            'run_id', 'phase', 'sample_idx'
        ] + ADC_COLS

        # Temperature & humidity adalah bagian kontrak CSV akuisisi aktif.
        ordered_cols += ['temperature', 'humidity']

        # Semua row collector selalu memiliki temperature/humidity. Jika
        # pembacaan SHT30 invalid, nilainya disimpan sebagai kosong/NaN agar
        # raw data tidak dibuang dan kegagalan sensor tetap terlihat.
        df = df[ordered_cols]

        # Preserve incomplete readings, but never publish an interrupted or
        # invalid capture as canonical data/raw/<name>.csv.
        raw_root = Path(OUTPUT_DIR)
        staging = raw_root / '.incoming'
        incomplete = raw_root / 'incomplete'
        staging.mkdir(parents=True, exist_ok=True)
        incomplete.mkdir(parents=True, exist_ok=True)
        temp = staging / (Path(out_csv).stem + '_' + uuid.uuid4().hex + '.partial.csv')
        df.to_csv(temp, index=False)
        issues = validate_file(temp)
        approved = collector.complete_received and not issues
        if approved:
            import os as _os
            from lcd_acquisition_service import unique_final_path
            # Exclusive hardlink publication prevents overwriting user files.
            destination = unique_final_path(Path(out_csv).name)
            _os.link(temp, destination)
            temp.unlink()
            out_csv = str(destination)
        else:
            destination = incomplete / (
                Path(out_csv).stem + '_' + uuid.uuid4().hex + '_INCOMPLETE.csv'
            )
            temp.replace(destination)
            out_csv = str(destination)
            print(f"WARNING: Sesi tidak final: {collector.failure_reason}; QA={issues}")

        collecting_n = len(df[df['phase'] == 'collecting'])
        purging_n    = len(df[df['phase'] == 'purging'])
        temperature_missing = int(df['temperature'].isna().sum())
        humidity_missing = int(df['humidity'].isna().sum())
        print(f"""
📄 DATA {'FINAL VALID' if approved else 'INCOMPLETE / HOLD'} DISIMPAN KE CSV!
   File Location : {out_csv}
   Sample ID     : {sample_id}
   Roast Level   : {roast_level}
   Origin        : {origin}
   Batch ID      : {batch_id}
   Purging Rows  : {purging_n} sampel
   Collect Rows  : {collecting_n} sampel
   Total Baris   : {len(df)} baris raw data
   Total Kolom   : {len(df.columns)} kolom
   Temp Missing  : {temperature_missing}
   Hum Missing   : {humidity_missing}
   
""")
        if temperature_missing or humidity_missing:
            print(
                "⚠️  WARNING: Ada data temperature/humidity kosong. "
                "CSV tetap disimpan agar raw acquisition tidak hilang. "
                "Periksa SHT30 sebelum pengambilan data berikutnya."
            )
        else:
            print("✅ Temperature dan humidity tersimpan lengkap.")
    else:
        print("\n⚠️ Tidak ada data yang diterima. File CSV tidak dibuat.")


if __name__ == '__main__':
    raise SystemExit(main())
